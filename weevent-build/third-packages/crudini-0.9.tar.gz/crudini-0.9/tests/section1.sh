dup1=val1
dup2=val2
nospace=val
multiline='with
leading
space'
nmultiline='not supported with\'
comment_after1=val
comment_after2='val;not a comment'
comment_after3='val #not a comment'
escaped_not_processed='test \nescape'
colon=val
double_quotes='"not removed"'
single_quotes=''"'"'not removed'"'"''
spaces_stripped=val
internal_not_stripped='v  al'
notempty1=';comment=val'
empty=''
python_interpolate='%(dup1)s/blah'
interpolate2='${dup1}/blah'
Caps='not significant'
combine=sections
